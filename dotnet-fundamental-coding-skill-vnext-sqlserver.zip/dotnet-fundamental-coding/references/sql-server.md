# Microsoft SQL Server — Focused Coding Reference

**Read this only when the user’s C#/.NET task actually touches Microsoft SQL Server** (including EF Core SQL Server, `SqlClient`/ADO.NET, Dapper, and existing T-SQL scripts or stored procedures). `SKILL.md` is authoritative. These rules do not authorize schema or code changes beyond the user's approved scope.

## 1. Identify existing ownership and SQL Server compatibility

- Inspect only the relevant existing code, `.csproj` references and database artifacts to identify whether the project uses EF Core, EF6, ADO.NET (`Microsoft.Data.SqlClient` or legacy `System.Data.SqlClient`), Dapper, raw SQL, views, or stored procedures. **Do not switch approaches simply because another looks shorter.**
- Respect the actual SQL Server version/database compatibility level, the application's .NET and EF version, connection configuration, naming conventions, `dbo` or other schema, and existing mapping/contract. Do not assume new T-SQL syntax is supported.
- Keep a query or stored procedure inside its established repository/service/database location. Do not create a new repository, service, generic data helper, or helper chain for a small query.
- Treat tables, views, columns, procedures, functions, triggers, permissions, migrations, indexes, jobs, configuration, and production data as **out of scope unless specifically approved**. A necessary extra database change must be proposed with reason, affected objects, risks, and a separate approval.
- **Never execute destructive or production-writing SQL, deployments, migrations, or `ALTER`/`DROP`/`TRUNCATE` without explicit authorization.** Reading definitions is not permission to modify them.

## 2. Prefer simple, debugger-friendly T-SQL

- Prefer straightforward `SELECT`, `FROM`, `JOIN`, `WHERE`, `CASE`, `ORDER BY`, `INSERT`, `UPDATE`, and `DELETE` where appropriate. Use `IF/ELSE`, `BEGIN/END`, and clearly named local variables for understandable procedural T-SQL.
- Avoid excessive nested subqueries, unnecessary CTE chains, dynamic SQL, cursor usage, temporary tables, table variables, and deeply nested `CASE` expressions **when a simple equivalent is sufficient**. A CTE, window function, set-based statement, or temp table is fine when it makes a genuinely complex request easier to understand or materially improves the query.
- Prefer set-based database operations over C# row-by-row database calls (`N+1`) or SQL cursors when a set-based query would be simpler and preserve required behavior. Do not split a working set-based query into many per-row requests merely to make C# use `foreach`.
- Return only required data when writing a new query, but **do not silently alter `SELECT *`, column order/names, or result-set shape in an existing contract**. Preserve aliases, output parameters, result sets, return codes, and mapping conventions.
- When the requested result relies on ordering, specify an appropriate `ORDER BY`, including a deterministic tie-breaker for paging or top-N if needed. SQL Server does **not** guarantee row order without `ORDER BY`.

## 3. Parameterize values; keep types correct

- **Never concatenate or interpolate untrusted values into executable SQL text.** Use SQL parameters through the existing data-access library. In EF Core raw SQL, use safe interpolated/parameterized APIs appropriate to the project's EF version. Do not inject user input into `FromSqlRaw` syntax.
- Match parameter SQL types/length/precision/scale where relevant, particularly dates, Unicode/non-Unicode strings, decimals, and nullable values. Type mismatches can change comparisons and execution plans. When a type is known, an explicit `SqlDbType` is often clearer than relying on inferred types; respect existing conventions when correct.
- SQL identifiers (table names, column names, `ORDER BY` identifiers) cannot be parameterized as ordinary values. If dynamic identifiers are genuinely required and approved, choose from a **fixed allowlist** rather than trusting raw user input.
- Preserve SQL Server null semantics (`NULL`, `IS NULL`, `DBNull.Value`), date/time handling, and parameter ordering/names. Do not invent guards for impossible nulls; keep guards necessary for real input and data integrity.
- Do not hardcode or log passwords, credentials, or full connection strings. Keep existing configuration/secret-management patterns.

**Avoid — interpolating a value directly into executable SQL:**

```csharp
string sql = $"SELECT Name FROM dbo.Customers WHERE Id = {customerId}";
```

**Prefer — direct, parameterized ADO.NET within the existing data-access owner:**

```csharp
using (var command = new SqlCommand(
    "SELECT Name FROM dbo.Customers WHERE Id = @CustomerId", connection))
{
    command.Parameters.Add("@CustomerId", SqlDbType.Int).Value = customerId;
    object name = command.ExecuteScalar();
    // Continue with the existing return/null contract.
}
```

Here `connection` is an existing open connection, and the snippet is illustrative; keep the project’s existing async vs sync path and return/null behavior. `using` for the command is not a reason to create a new helper or repository. Preserve transaction assignment if one exists.

## 4. EF Core + SQL Server: server-side first

- Keep `Where`, `Select`, `OrderBy`, `Any`, grouping, aggregation and paging provider-translatable where appropriate; materialize only after the desired database operation. Complex *in-memory* LINQ may be replaced with `foreach` if user-approved, but not `IQueryable` SQL processing.
- Avoid `ToList`, `AsEnumerable` or per-record calls before filtering just to replace LINQ with loops. Preserve eager/lazy loading decisions and avoid introducing N+1 database round trips.
- Do not change tracking behavior (`AsNoTracking`), collation, query filters, entity configuration, migrations, isolation level, or provider configuration unless that is part of the approved request.
- Respect installed EF Core and provider versions. For raw SQL, use the safe parameterization API for that version; do not blindly copy newer `FromSql` overloads into legacy code.

**Clear, server-side EF example:**

```csharp
var customers = await db.Customers
    .Where(customer => customer.IsActive)
    .Select(customer => new { customer.Id, customer.Name })
    .ToListAsync(cancellationToken);
```

This example is **not** a command to introduce EF Core into a project that already uses ADO.NET, Dapper, or stored procedures.

## 5. Stored procedures, transactions, and consistency

- If the module uses an existing stored procedure, prefer modifying its **existing authorized SQL body or call site** rather than replicating its rules in C#. If changing both caller and stored procedure is necessary, explain both objects and obtain approval before either out-of-scope edit.
- Preserve procedure name, schema, parameter defaults/types, output parameters, return code, returned columns, row-count behavior if callers depend on it, and exception/error signaling. Do not add new procedures or nested procedure chains to avoid inline T-SQL.
- Keep transaction boundaries and ownership unchanged. For multi-step writes requiring atomicity, preserve the existing commit/rollback policy; do not add or remove `BEGIN TRAN`, `COMMIT`, isolation hints, `SET XACT_ABORT`, retry loops, or broad exception swallowing casually.
- SQL Server transaction errors can leave transactions uncommittable (`XACT_STATE() = -1`); handle actual transaction requirements deliberately. Do not automatically wrap every small statement in a new transaction.
- Do not add `WITH (NOLOCK)`, `READ UNCOMMITTED`, `MERGE`, `OPTION` hints, or index changes as speculative optimizations. These alter correctness/concurrency or plan behavior and require a task-specific reason and user approval.

## 6. Performance, safety, and verification

- Start with a clear query and actual requirements, not speculative tuning. When performance is explicitly in scope, investigate supported evidence (query plan, Query Store, row counts, index availability) before proposing targeted changes; avoid guessing indexes, hints, or rewrites.
- Before changing a database query, identify the known expected row count/order, null behavior, duplicates, affected rows, and caller mapping; make the smallest necessary change.
- Validate against an **approved disposable local/test SQL Server** when available. A successful compile does not prove SQL validity or that a stored procedure still returns the required shape. Never imply that production data was tested if only source was inspected.
- Report which database files/objects were changed, whether a SQL connection or query was actually executed, the relevant verification performed, and any testing not run. Never disclose credentials or connection strings.

## Sources (Microsoft documentation)

- [SQL Server EF Core provider / version-specific configuration](https://learn.microsoft.com/en-us/ef/core/providers/sql-server/)
- [EF Core SQL queries and parameterization](https://learn.microsoft.com/en-us/ef/core/querying/sql-queries)
- [ADO.NET parameters and provider types](https://learn.microsoft.com/en-us/dotnet/framework/data/adonet/configuring-parameters-and-parameter-data-types)
- [SQL Server `ORDER BY` and stable paging](https://learn.microsoft.com/en-us/sql/t-sql/queries/select-order-by-clause-transact-sql)
- [SQL Server stored procedures](https://learn.microsoft.com/en-us/sql/relational-databases/stored-procedures/stored-procedures-database-engine)
- [T-SQL `TRY...CATCH` and `XACT_STATE`](https://learn.microsoft.com/en-us/sql/t-sql/language-elements/try-catch-transact-sql)
- [SQL Server query execution plans](https://learn.microsoft.com/en-us/sql/relational-databases/performance/execution-plans/)
- [SQL Server Query Store performance investigations](https://learn.microsoft.com/en-us/sql/relational-databases/performance/monitoring-performance-by-using-the-query-store)
