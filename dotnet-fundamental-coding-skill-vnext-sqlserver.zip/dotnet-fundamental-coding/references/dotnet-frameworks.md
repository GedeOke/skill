# .NET Framework-Specific Boundaries

Read the relevant subsection when working on that kind of project. Preserve the *actual installed version* and existing architectural ownership; never infer that an API is available from the modern .NET name alone.

## ASP.NET Core Web API / Minimal API / MVC

- Keep existing controller/endpoint route, HTTP result/status contracts, authentication/authorization, middleware, error handling, service ownership and dependency injection behavior.
- Where a service currently owns business rules, modify that service rather than moving logic into an action to reduce call depth.
- Avoid creating new controller -> handler -> manager -> service forwarding chains without approval.
- Use async I/O and pass cancellation tokens when already part of the contract; do not replace asynchronous calls with `.Result` or `.Wait()`.
- Do not change `Program.cs`, `appsettings`, routing, models, migrations, DI registrations, or cross-cutting behavior unless specifically authorized.

## Entity Framework Core

- Distinguish `IQueryable<T>` (provider-translated queries) from `IEnumerable<T>` (often in-memory enumeration).
- Keep necessary filtering/projection/aggregation on the database side when possible; do not call `.AsEnumerable()`/`.ToList()` before conditions merely to enable loops.
- Do not introduce lazy-loading N+1 patterns, change transaction/commit behavior, or alter tracking semantics without a direct need and approval.
- Do not assume EF Core InMemory is equivalent to a relational database for tests; reuse an existing appropriate test strategy.

## Microsoft SQL Server (conditional)

- When a task involves SQL Server T-SQL, SqlClient/ADO.NET, Dapper, EF Core SQL Server or stored procedures, consult [SQL Server safeguards](sql-server.md).
- Parameterize SQL values, preserve transaction and stored procedure contracts, and do not change schema or data outside approved scope.
- Keep set-based SQL/provider-side filtering when appropriate; minimal LINQ does not authorize premature materialization or N+1 loops.

## Windows Forms (WinForms)

- Preserve `*.Designer.cs` ownership, event wiring, control names/layout, `InitializeComponent`, and existing event signatures. Do not edit Designer-generated code without specific authorization.
- Keep UI access on the UI thread. Await asynchronous operations without blocking the message loop. Avoid using `.Result` / `.Wait()` on the UI thread or `Task.Run` around asynchronous I/O just for appearance.
- If marshaling is required, choose an API available in the project's actual target: `Control.InvokeAsync` is a .NET 9+ WinForms API and should not be introduced into legacy .NET Framework projects.
- Do not add methods solely to forward a click event into another one-line wrapper. Preserve existing service ownership when it exists.

## Console / Worker / Background Services

- Preserve entry point, exit codes, stdout/stderr conventions, command dispatching, cancellation/shutdown, schedules and configured service lifetimes.
- Prefer direct, sequential processing for a small command; avoid nesting helper methods inside `Main`.
- Do not introduce extra hosted services, CLI layers, or startup rewriting without explicit permission.

## WPF / Blazor / Razor / Class Libraries

- Preserve existing MVVM/component/service boundaries, UI dispatcher or synchronization requirements, lifecycle contracts, bindings and public APIs.
- Avoid moving view-model or service responsibilities into code-behind/components to simulate a single execution path.
- Implement inside the current responsibility owner and stay compatible with current target/runtime.

## Legacy .NET Framework / C# compatibility

- Inspect `.csproj`, target framework, configured `LangVersion`, compiler/runtime and installed packages before using newer language syntax or APIs.
- Do not raise target framework, update dependencies, alter nullable settings, or set `LangVersion=latest` without approval.

## Build, diff and verification

1. Inspect `git status` and the relevant diff; respect preexisting uncommitted edits.
2. After the authorized edit, review changed files (`git diff --name-only`), the exact patch (`git diff`), and whitespace errors (`git diff --check`) when Git is available.
3. Run the smallest safe existing build/tests appropriate to the changed project; do not install packages, run migrations, reformat whole solutions, or add test scaffolding without approval.
4. State results precisely: `not run` means not run; a successful build is not the same as passing tests.
5. If resolving a necessary blocker means altering unapproved files or contracts, stop before that expansion and ask.

## Source references for technical caveats

- [Microsoft: C# coding conventions](https://learn.microsoft.com/en-us/dotnet/csharp/fundamentals/coding-style/coding-conventions)
- [Microsoft: C# language version configuration](https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/configure-language-version)
- [Microsoft: ASP.NET Core performance best practices](https://learn.microsoft.com/en-us/aspnet/core/fundamentals/best-practices)
- [Microsoft: EF Core efficient querying](https://learn.microsoft.com/en-us/ef/core/performance/efficient-querying)
- [Microsoft: EF Core client/server evaluation](https://learn.microsoft.com/en-us/ef/core/querying/client-eval)
- [Microsoft: WinForms cross-thread operations](https://learn.microsoft.com/en-us/dotnet/desktop/winforms/controls/how-to-make-thread-safe-calls)
- [Microsoft: EF Core testing strategies](https://learn.microsoft.com/en-us/ef/core/testing/choosing-a-testing-strategy)
- [Agent Skills specification](https://agentskills.io/specification)
