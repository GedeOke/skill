# C# Style Decisions — Reference Examples

Use this reference for C# implementation decisions. The main `SKILL.md` remains authoritative; examples are illustrative, not permission to refactor existing code.

## Debugging: one readable flow, not a chain of wrappers

Avoid optional forwarding chains:

```csharp
private void btnSave_Click(object sender, EventArgs e)
{
    HandleSave();
}

private void HandleSave() => ProcessSave();
private void ProcessSave() => SaveName();
private void SaveName() => _repository.Save(txtName.Text);
```

Prefer a simple sequence in the *existing owner* when the work is actually small:

```csharp
private void btnSave_Click(object sender, EventArgs e)
{
    string name = txtName.Text;
    _repository.Save(name);
    MessageBox.Show("Saved");
}
```

This assumes the existing repository call is appropriate and safe on the UI thread. Do not move existing service business rules into the event handler. If persistence is slow or async, use a framework-appropriate asynchronous pattern instead of blocking the UI.

## In-memory multi-step logic: prefer inspectable statements

Avoid compressing business steps into a long fluent LINQ pipeline:

```csharp
decimal total = records
    .Where(record => record.IsActive)
    .SelectMany(record => record.Items)
    .Where(item => item.Price > 100)
    .Select(item => item.Price * item.Quantity)
    .Sum();
```

Prefer a loop when records are **already in memory**:

```csharp
decimal total = 0;

foreach (var record in records)
{
    if (!record.IsActive)
        continue;

    foreach (var item in record.Items)
    {
        if (item.Price <= 100)
            continue;

        total += item.Price * item.Quantity;
    }
}
```

Do not substitute this loop for an EF Core `IQueryable` server query. Avoid changing the existing code solely to enforce a style preference.

### Short LINQ is permitted

```csharp
bool hasActiveItems = items.Any(item => item.IsActive);
```

No need to replace this with a manual loop if it is clearer, matches the module, and preserves provider semantics.

### EF Core: provider-side filtering/projection

```csharp
var orders = await db.Orders
    .Where(order => order.IsActive)
    .Select(order => new { order.Id, order.Total })
    .ToListAsync(cancellationToken);
```

Filtering and projecting happen before materialization. Never insert an early `.AsEnumerable()` or `.ToList()` simply to switch to `foreach`. Treat provider-specific translation and query behavior as part of correctness.

## Conditions and variables

- Use `if/else` or a standard `switch` for multi-statement branches; prefer `switch` when repeatedly deciding on one value.
- Use `continue`/`return` to reduce nesting **only if** condition order, side effects, and exception behavior remain the same.
- Prefer `customer`, `totalPrice`, `isActive`; avoid ceremonial names such as `currentCustomerEntityInstance`.
- Introduce an intermediate variable when it conveys meaning or helps breakpoint inspection, not to give every trivial expression a name.
- Avoid comments such as `// Set name to text`; explain only non-obvious rules or decisions.
- Do not introduce 1–2-line helpers, local functions, nested lambdas, or new abstractions to reduce method length. If genuinely distinct responsibilities make a large method difficult to maintain, request approval for a clearly named extraction.

## Defensive code is proportional

Validate data that is untrusted, can be missing, or can violate an actual contract. Preserve authorization, data integrity, input boundaries, correct exception behavior, and framework-required guards. Do not add cascades of speculative null checks, broad `try/catch` blocks that swallow errors, or redundant validation when existing boundaries already guarantee the invariant.

## Natural developer code and minimal diffs

- Follow neighboring code style and `.editorconfig`, without reformatting existing unaffected code.
- Prefer supported, familiar language features over using the newest syntax for its own sake.
- Preserve method signatures, return shapes, async behavior, and existing collaborators.
- A concise, coherent method is preferable to a web of forwarding helpers; a single huge method covering unrelated responsibilities is also not a goal.
- Never modify code beyond the approved request to make the style more uniform.
