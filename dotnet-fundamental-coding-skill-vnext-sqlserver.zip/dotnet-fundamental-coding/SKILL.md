---
name: dotnet-fundamental-coding
description: Write or edit C#/.NET code for ASP.NET Core, Console, WinForms, WPF, Blazor, workers, libraries, and legacy .NET with minimal scoped changes, confirmed user logic, existing-project consistency, fundamental C# control flow, minimal LINQ, zero unnecessary helpers, SQL Server-aware database changes when relevant, and straightforward step-through debugging. Use when implementing, changing, reviewing, or advising on .NET code.
---

# .NET Fundamental Coding

**Goal:** Produce natural, human-written C# that is easy to read, debug, and change. Follow the user's approved behavior **in the stated order**, inside the existing component that owns it. Prefer a small, understandable diff over elegant-looking abstractions.

Applies to ASP.NET Core APIs, MVC, Razor Pages, Blazor, Console, WinForms, WPF, workers, class libraries, and .NET Framework projects, including applications that use Microsoft SQL Server. Respect the existing target framework, C# version, dependencies, architecture, and `.editorconfig`.

## Priority rules (mandatory)

1. **Approval before behavioral edits.** Before changing behavior, inspect relevant code, restate the user-requested step sequence and the exact intended edit boundary, and ask whether the logic is correct. **Do not edit until approved.** If this precise flow and scope have already been unambiguously approved, proceed without asking again. For advice/review-only requests, answer without demanding approval.
2. **Strict scope protection.** Only edit what the user explicitly authorized. Treat every other method, file, condition, comment, import, format choice, and configuration as read-only context. Never perform unsolicited cleanup, refactoring, renaming, optimization, formatting, feature additions, or bug fixes. Reading unrelated code is allowed; changing it is not.
3. **Preserve behavior outside scope.** Do not alter unrelated branch conditions or evaluation order, short-circuiting, return values/status codes, exceptions, side effects, authorization, data integrity, transactions, async/cancellation, database query execution, UI-thread behavior, or framework/public contracts. Do not weaken essential safety/security checks for the sake of minimal validation.
4. **Default: zero new optional helpers.** Keep one coherent requested flow visible in the *existing method or component that owns it*. Avoid nested/local functions, forwarding wrappers, one- or two-line helpers, `Handle -> Process -> Execute` chains, speculative services, interfaces, DTOs, repositories, utility classes, extensions, factories, managers, and new DI layers. Do **not** inline or duplicate established services merely to reduce method-call depth.
5. **Approval gate for optional method boundaries.** A new method/class is justified only by explicit user instruction, substantial real reuse, or a distinct responsibility whose separation materially improves clarity; framework-required entry points/implementations are exceptions. Before creating any *optional* new method/class, state its intended purpose, location, callers, and why inline code is insufficient, then obtain explicit approval. Do not turn this rule into a giant unreadable method.
6. **Fundamental C# first.** For multi-step in-memory logic, prefer explicit `if/else`, `switch/case`, `foreach`, `for`, `while`, `break`, `continue`, `return`, and useful intermediate variables when clearer for debugging. Avoid long fluent LINQ, nested lambdas, chained transformations, clever ternaries, and hard-to-inspect expressions. Short, obvious LINQ is fine when more readable. **Keep EF Core/`IQueryable` work on the provider/server when applicable**; never materialize early just to use `foreach`.
7. **Natural, cohesive, human-written code.** Prefer conventional statements, practical short-but-meaningful names, shallow control flow, and purpose-driven variables. Use guard clauses only when they preserve behavior. Comments explain non-obvious *why*, not obvious *what*. No unnecessary validations, null checks, `try/catch`, logging, defensive wrappers, variables, interfaces, or abstraction layers; preserve checks necessary for correctness or safety.
8. **Existing project wins on local conventions.** Match nearby naming, formatting, indentation, organization, and method ownership without rewriting neighboring code. Where the project's coding-style preference is not already selected, offer **A) Match Existing Style (recommended), B) Fundamental .NET Style, or C) Hybrid**. Ask once per project, combined with logic confirmation; respect the user's choice thereafter. All choices still obey scope protection and the no-unnecessary-helpers policy.
9. **Suggestions are proposals, not permission.** If asked for suggestions, explain options and tradeoffs. Never implement one without the user's specific approval. If an essential requested edit cannot be done without touching an out-of-scope location, **stop before that edit**, describe the minimal additional scope and impact, and request approval.
10. **Minimum reliable verification.** Inspect the exact diff and changed-file list; separate your edits from preexisting user changes. When safe and available, run the smallest relevant existing build/tests. Do not run project-wide formatters, bulk fixes, scaffolding, migrations, dependency upgrades, or broad test suites merely for tidiness. Never claim to have tested or built something you did not actually run.

## Choose the correct coding boundary

- **Existing service/repository/handler owns the operation?** Modify that owner; do not move business logic to a controller or UI event just to make it linear.
- **Simple operation belongs to an existing controller action, Minimal API endpoint, `Main`, or WinForms handler?** Keep the approved sequence there rather than inventing wrappers.
- **Framework requires an interface implementation, event handler, lifecycle method, lambda, or separate file?** Use the required shape; this is not permission to add optional abstraction chains.
- **Method is getting long?** First improve naming, grouping, and straightforward flow. If there are truly different responsibilities or substantial reuse, propose a specific extraction and seek approval.
- **EF Core / database query?** Use server-translatable query expressions and deliberate materialization; avoid replacing an `IQueryable` with a client loop.
- **Project uses Microsoft SQL Server?** Keep the existing EF Core, ADO.NET, Dapper, or stored procedure approach; parameterize input; prefer readable T-SQL; preserve result shapes, transactions, null handling, and database contracts. Never change schemas, stored procedures, indexes, permissions, or production data beyond explicit approval. Read [SQL Server safeguards](references/sql-server.md) for database work.

See [C# decision examples](references/csharp-style.md), [framework safeguards](references/dotnet-frameworks.md), and [SQL Server safeguards](references/sql-server.md) **only when relevant to the task**.

## Required workflow

### 1. Inspect; do not edit

- Identify the current target framework/language version, the existing owner, local conventions, and the smallest file/method/statement boundary.
- Derive the operation sequence exactly as requested; keep optional suggestions separate.
- Note important behavior/contracts to preserve and whether a collection is in-memory or provider-backed. For SQL Server work, inspect the data access pattern, query/stored procedure contract, affected objects, and transaction boundary.
- Check for user edits already present; never discard them.

### 2. Confirm the plan with the user

For a behavior-changing task that has not already been approved, ask briefly:

```text
I understand the requested flow as:
1. [operation]
2. [operation]
3. [result]

Proposed edit: [existing file and method]. No new optional helpers or
unrelated changes.
[For an existing project without a recorded choice:]
Style: A) Match existing  B) Fundamental .NET  C) Hybrid

Is that flow correct? [And which style do you choose?]
```

Ask only substantive questions. When the user has already confirmed these details, **do not block on repetitive questions**.

### 3. Implement the approved minimum

- Edit only the approved location, preserving request order and existing responsibility boundaries.
- Use fundamental syntax for inspectable in-memory steps; use short LINQ only if clearer; preserve EF/query translation.
- Do not add optional methods/classes, features, validation, formatting, dependencies, or refactoring without a separate approval.
- Keep naming, comment density, indentation, and syntax compatible with the targeted project.
- If unavoidable work exceeds scope, stop **before** that additional work and ask.

### 4. Check and report

- Review changed files and the patch (`git diff --name-only`, `git diff`, `git diff --check` when applicable); do not overwrite other people's edits.
- Check for accidental behavior changes: branching and order, return/exception/HTTP contracts, async/UI threading, auth, EF materialization, SQL Server result/transaction semantics when relevant, and existing callers.
- Verify only with safe, relevant available tools; say precisely which checks were run and which were not.
- Report: **what changed, where, whether optional helpers were added, any untouched concerns, and actual verification**.

## Resolve tensions in this order

**Correctness, essential security and framework constraints** are never intentionally violated. Within those constraints: **approved user logic and scope > established project ownership/contracts > clear fundamental C# and debuggability > natural local style > optional suggestions**. When two constraints cannot both be met within the approved scope, explain the blocker and ask rather than silently expanding the patch.

## Evaluation

Use [15 proposed agent scenarios](evals/evals.json) and [grading guide](evals/README.md) to measure whether these rules affect actual coding-agent behavior. **These scenarios have not been executed; do not claim a measured pass rate.**
