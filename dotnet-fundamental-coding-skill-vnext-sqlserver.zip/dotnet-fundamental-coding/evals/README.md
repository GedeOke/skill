# Skill Acceptance Evaluation (Not Yet Run)

The 15 cases in `evals.json` are **evaluation specifications**, not evidence of model performance. Do not claim pass rates until executed on the intended coding agent with representative C# repositories.

## How to evaluate

1. Make a disposable test copy of each relevant repository with known initial state and seeded preexisting edits.
2. Run each scenario twice if possible: without skill (baseline) and with vNext enabled, using the same user approval responses and repo snapshot.
3. Record the generated code diff, modified files, any newly declared methods/classes, approval dialogue and actual build/test logs.
4. Mark a scenario **FAIL** if any listed `hard_fail_if` condition occurs; never offset a hard fail with stylistic strengths.
5. For cases without hard failures, grade each applicable soft dimension from 0 (poor) to 2 (good): sequential debugging, existing-style consistency, minimal diff, correct LINQ/loop choice, honest verification.
6. Investigate observed failures. Adjust only the relevant rule or example, rerun, and keep the final skill concise.

## Release quality checklist

- No unauthorized edits or optional method/class creation; SQL Server schema/procedure/production data remain protected.
- No unrelated behavior changes, forced client evaluation, unparameterized SQL inputs, unsupported .NET APIs, or false claims about checks.
- Logic confirmation happens once when required and is not repeated after explicit approval.
- Existing module ownership and framework contracts remain intact.
- Source diffs remain small and readable; failed verification is reported, not concealed.

**Current status: NOT EXECUTED.** No numeric pass/fail rates are available.
