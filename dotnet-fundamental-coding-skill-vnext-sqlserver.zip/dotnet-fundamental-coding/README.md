# .NET Fundamental Coding Skill — vNext

A portable Agent Skill for natural, debugger-friendly, minimal-scope C#/.NET coding. All approved earlier rules remain in effect, with redundant instructions condensed into a short `SKILL.md` and focused references.

## Contents

- `SKILL.md` — primary agent instructions. Start here.
- `references/csharp-style.md` — examples of readable linear code, minimum LINQ, method gates, and human-written conventions.
- `references/dotnet-frameworks.md` — framework-specific correctness boundaries, verification, documentation links.
- `references/sql-server.md` — SQL Server-only guidance for EF Core, ADO.NET/SqlClient, Dapper, T-SQL, stored procedures, transactions, parameterization, and schema safety.
- `evals/evals.json` — 15 **unexecuted** agent evaluation scenarios.
- `evals/README.md` — evaluation protocol and quality gates.

## Installation

Unzip the package into the `skills/` location supported by your agent, preserving the `dotnet-fundamental-coding` directory and its contents. Whether and how a skill activates varies by agent. Do not confuse this package with project-wide always-on instructions such as `AGENTS.md` or `.github/copilot-instructions.md`.

## What changed from the approved prior version

- Kept: logic confirmation, user-controlled suggestions, strict minimal diffs, zero optional helpers by default, no local/nested functions for simple work, linear debugging, fundamental syntax/minimal LINQ, existing project style A/B/C, the seven human-written-code rules, and cross-framework applicability.
- Clarified: the **current responsibility owner** is more important than minimizing method-call depth; preserve existing service boundaries and required security/async/data behavior.
- Added: explicit framework-specific safeguards, a concise verification contract, and 15 unexecuted evaluation scenarios.
- Extended: optional SQL Server guidance, with mandatory parameterization and schema/production-data scope protections when SQL Server is actually involved.
- Refactored **the skill documentation only**, not anyone's application code.

## Evaluation status

The skill package and JSON are structurally checked. **No live agent coding tests have been performed**. Use the included evaluation protocol before claiming the skill improves compliance in production.
